CREATE DATABASE  IF NOT EXISTS `quennie` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `quennie`;
-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: quennie
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `customer_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(20) DEFAULT NULL,
  `registration_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_login` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (2,3,'Penuel','User',NULL,NULL,NULL,NULL,'2026-09-24 03:38:12'),(3,2,'adriel','User',NULL,NULL,NULL,NULL,'2026-09-24 04:51:40'),(4,4,'Samantha','User',NULL,NULL,NULL,NULL,'2026-09-28 23:46:29'),(5,5,'vincent','User',NULL,NULL,NULL,NULL,'2026-09-29 00:18:09'),(6,6,'JC','User',NULL,NULL,NULL,NULL,'2026-09-29 00:19:28'),(7,9,'test','User',NULL,NULL,NULL,NULL,'2026-10-08 12:45:43');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `farmer`
--

DROP TABLE IF EXISTS `farmer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `farmer` (
  `farmer_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `farm_name` varchar(100) NOT NULL,
  `owner_name` varchar(100) NOT NULL,
  `contact_email` varchar(100) DEFAULT NULL,
  `farm_address` varchar(255) DEFAULT NULL,
  `rating` decimal(3,2) DEFAULT NULL,
  `joined_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`farmer_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `farmer_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_login` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `farmer`
--

LOCK TABLES `farmer` WRITE;
/*!40000 ALTER TABLE `farmer` DISABLE KEYS */;
INSERT INTO `farmer` VALUES (1,2,'Adriel\'s Farm','Adriel',NULL,NULL,NULL,'2026-09-24 03:37:56'),(2,6,'JC\'s Farm','JC',NULL,NULL,NULL,'2026-09-29 00:19:28'),(3,9,'test\'s Farm','test',NULL,NULL,NULL,'2026-10-08 12:45:43');
/*!40000 ALTER TABLE `farmer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order` (
  `order_id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `order_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `total_amount` decimal(10,2) NOT NULL,
  `delivery_address` varchar(255) NOT NULL,
  `special_instructions` text,
  PRIMARY KEY (`order_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `order_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES (2,3,'2026-09-24 04:51:58',250.00,'Standard Delivery',NULL),(3,2,'2026-09-24 04:52:12',250.00,'Standard Delivery',NULL),(4,2,'2026-09-24 04:52:25',7000.00,'Standard Delivery',NULL),(5,3,'2026-09-24 04:55:40',250.00,'Standard Delivery',NULL),(6,3,'2026-09-24 04:55:44',2500.00,'Standard Delivery',NULL),(7,3,'2026-09-28 23:45:15',250.00,'Standard Delivery',NULL),(8,3,'2026-09-28 23:45:27',2000.00,'Standard Delivery',NULL),(9,4,'2026-09-28 23:46:59',4000.00,'Standard Delivery',NULL),(10,4,'2026-09-29 00:02:38',2500.00,'Standard Delivery',NULL),(11,4,'2026-09-29 00:03:03',2500.00,'Standard Delivery',NULL),(12,3,'2026-09-29 00:04:37',2500.00,'Standard Delivery',NULL),(13,3,'2026-09-29 00:10:13',2500.00,'Standard Delivery',NULL),(14,3,'2026-09-29 00:16:53',500.00,'Standard Delivery',NULL),(15,5,'2026-09-29 00:18:44',500.00,'Standard Delivery',NULL),(16,6,'2026-09-29 00:21:14',90.00,'Standard Delivery',NULL),(17,4,'2026-09-29 00:38:03',2500.00,'Standard Delivery',NULL),(18,4,'2026-09-29 00:47:10',150.00,'Standard Delivery',NULL),(19,3,'2026-09-29 01:04:29',250.00,'Standard Delivery',NULL),(20,3,'2026-09-29 01:10:31',156.00,'Standard Delivery',NULL),(21,3,'2026-09-29 01:14:09',600.00,'Standard Delivery',NULL),(22,4,'2026-09-29 22:44:47',500.00,'Standard Delivery',NULL),(23,4,'2026-09-30 01:21:50',1200.00,'Standard Delivery',NULL),(24,6,'2026-09-30 01:35:09',500.00,'Standard Delivery',NULL),(25,3,'2026-10-08 12:20:41',50.00,'Standard Delivery',NULL),(26,3,'2026-10-08 12:21:46',500.00,'Standard Delivery',NULL),(27,3,'2026-10-08 12:23:11',500.00,'Standard Delivery',NULL),(28,3,'2026-10-08 12:24:55',50.00,'Standard Delivery',NULL),(29,3,'2026-10-08 12:25:03',50.00,'Standard Delivery',NULL),(30,3,'2026-10-08 12:32:05',500.00,'Standard Delivery',NULL),(31,3,'2026-10-08 12:33:17',500.00,'Standard Delivery',NULL),(32,7,'2026-10-08 12:47:12',50.00,'Standard Delivery',NULL);
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_item`
--

DROP TABLE IF EXISTS `order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_item` (
  `order_item_id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `produce_id` int NOT NULL,
  `quantity` int NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`),
  KEY `produce_id` (`produce_id`),
  CONSTRAINT `order_item_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`) ON DELETE CASCADE,
  CONSTRAINT `order_item_ibfk_2` FOREIGN KEY (`produce_id`) REFERENCES `produce` (`produce_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_item`
--

LOCK TABLES `order_item` WRITE;
/*!40000 ALTER TABLE `order_item` DISABLE KEYS */;
INSERT INTO `order_item` VALUES (1,2,3,5,50.00),(2,3,3,5,50.00),(3,4,4,100,70.00),(4,5,3,5,50.00),(5,6,5,5,500.00),(6,7,3,5,50.00),(7,8,6,1,2000.00),(8,9,3,80,50.00),(9,10,5,5,500.00),(10,11,5,5,500.00),(11,12,5,5,500.00),(12,13,5,5,500.00),(13,14,8,10,50.00),(14,15,8,10,50.00),(15,16,9,3,30.00),(16,17,5,5,500.00),(17,18,9,5,30.00),(18,19,5,1,500.00),(19,20,9,5,30.00),(20,21,9,20,30.00),(21,22,11,10,50.00),(22,23,9,40,30.00),(23,24,12,1,500.00),(24,25,8,1,50.00),(25,26,5,1,500.00),(26,27,5,1,500.00),(27,28,8,1,50.00),(28,29,8,1,50.00),(29,30,5,1,500.00),(30,31,5,1,500.00),(31,32,13,1,50.00);
/*!40000 ALTER TABLE `order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_status`
--

DROP TABLE IF EXISTS `order_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_status` (
  `status_id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `current_status` varchar(50) NOT NULL,
  `date_timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `notes` text,
  PRIMARY KEY (`status_id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `order_status_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_status`
--

LOCK TABLES `order_status` WRITE;
/*!40000 ALTER TABLE `order_status` DISABLE KEYS */;
INSERT INTO `order_status` VALUES (1,2,'Finished','2026-09-24 04:51:58',NULL),(2,3,'Finished','2026-09-24 04:52:12',NULL),(3,4,'Finished','2026-09-24 04:52:25',NULL),(4,5,'Finished','2026-09-24 04:55:40',NULL),(5,6,'Finished','2026-09-24 04:55:44',NULL),(6,7,'Finished','2026-09-28 23:45:16',NULL),(7,8,'Finished','2026-09-28 23:45:27',NULL),(8,9,'Finished','2026-09-28 23:46:59',NULL),(9,10,'Finished','2026-09-29 00:02:38',NULL),(10,11,'Finished','2026-09-29 00:03:03',NULL),(11,12,'Finished','2026-09-29 00:04:37',NULL),(12,13,'Finished','2026-09-29 00:10:13',NULL),(13,14,'Finished','2026-09-29 00:16:53',NULL),(14,15,'Finished','2026-09-29 00:18:44',NULL),(15,16,'Paid','2026-09-29 00:21:14',NULL),(16,17,'Finished','2026-09-29 00:38:03',NULL),(17,18,'Finished','2026-09-29 00:47:10',NULL),(18,19,'Finished','2026-09-29 01:04:29',NULL),(19,20,'Paid','2026-09-29 01:10:31',NULL),(20,21,'Paid','2026-09-29 01:14:09',NULL),(21,22,'Paid','2026-09-29 22:44:47',NULL),(22,23,'Paid','2026-09-30 01:21:50',NULL),(23,24,'Finished','2026-09-30 01:35:09',NULL),(24,25,'Finished','2026-10-08 12:20:41',NULL),(25,26,'Finished','2026-10-08 12:21:46',NULL),(26,27,'Finished','2026-10-08 12:23:11',NULL),(27,28,'Finished','2026-10-08 12:24:55',NULL),(28,29,'Finished','2026-10-08 12:25:03',NULL),(29,30,'Paid','2026-10-08 12:32:05',NULL),(30,31,'Paid','2026-10-08 12:33:17',NULL),(31,32,'Paid','2026-10-08 12:47:12',NULL);
/*!40000 ALTER TABLE `order_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `payment_status` varchar(50) NOT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `payment_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `amount` decimal(10,2) NOT NULL,
  `card_number_last4` varchar(4) DEFAULT NULL,
  `card_holder_name` varchar(100) DEFAULT NULL,
  `card_type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (1,2,'Direct Gateway','Completed',NULL,'2026-09-24 04:51:58',250.00,NULL,NULL,NULL),(2,3,'Direct Gateway','Completed',NULL,'2026-09-24 04:52:12',250.00,NULL,NULL,NULL),(3,4,'Direct Gateway','Completed',NULL,'2026-09-24 04:52:25',7000.00,NULL,NULL,NULL),(4,5,'Direct Gateway','Completed',NULL,'2026-09-24 04:55:40',250.00,NULL,NULL,NULL),(5,6,'Direct Gateway','Completed',NULL,'2026-09-24 04:55:44',2500.00,NULL,NULL,NULL),(6,7,'Direct Gateway','Completed',NULL,'2026-09-28 23:45:16',250.00,NULL,NULL,NULL),(7,8,'Direct Gateway','Completed',NULL,'2026-09-28 23:45:27',2000.00,NULL,NULL,NULL),(8,9,'Direct Gateway','Completed',NULL,'2026-09-28 23:46:59',4000.00,NULL,NULL,NULL),(9,10,'Credit/Debit Card','Completed',NULL,'2026-09-29 00:02:38',2500.00,'4444','Samantha','MasterCard'),(10,11,'Credit/Debit Card','Completed',NULL,'2026-09-29 00:03:03',2500.00,'5555','Isla','Visa'),(11,12,'Cash on Delivery','Completed',NULL,'2026-09-29 00:04:37',2500.00,NULL,NULL,NULL),(12,13,'Cash on Delivery','Completed',NULL,'2026-09-29 00:10:13',2500.00,NULL,NULL,NULL),(13,14,'Cash on Delivery','Completed',NULL,'2026-09-29 00:16:53',500.00,NULL,NULL,NULL),(14,15,'Credit/Debit Card','Completed',NULL,'2026-09-29 00:18:44',500.00,'6666','vincent','Visa'),(15,16,'Credit/Debit Card','Completed',NULL,'2026-09-29 00:21:14',90.00,'8888','vincent','Visa'),(16,17,'Credit/Debit Card','Completed',NULL,'2026-09-29 00:38:03',2500.00,'4444','Samantha','Visa'),(17,18,'Credit/Debit Card','Completed',NULL,'2026-09-29 00:47:10',150.00,'4444','Samantha','Visa'),(18,19,'Cash on Delivery','Completed',NULL,'2026-09-29 01:04:29',250.00,NULL,NULL,NULL),(19,20,'Cash on Delivery','Completed',NULL,'2026-09-29 01:10:31',156.00,NULL,NULL,NULL),(20,21,'Credit/Debit Card','Completed',NULL,'2026-09-29 01:14:09',600.00,'7788','Adriel Sopera','Visa'),(21,22,'Credit/Debit Card','Completed',NULL,'2026-09-29 22:44:47',500.00,'0099','Sophia','MasterCard'),(22,23,'Credit/Debit Card','Completed',NULL,'2026-09-30 01:21:50',1200.00,'1111','JC','MasterCard'),(23,24,'Cash on Delivery','Completed',NULL,'2026-09-30 01:35:09',500.00,NULL,NULL,NULL),(24,25,'Cash on Delivery','Completed',NULL,'2026-10-08 12:20:41',50.00,NULL,NULL,NULL),(25,26,'Cash on Delivery','Completed',NULL,'2026-10-08 12:21:46',500.00,NULL,NULL,NULL),(26,27,'Cash on Delivery','Completed',NULL,'2026-10-08 12:23:11',500.00,NULL,NULL,NULL),(27,28,'Cash on Delivery','Completed',NULL,'2026-10-08 12:24:55',50.00,NULL,NULL,NULL),(28,29,'Cash on Delivery','Completed',NULL,'2026-10-08 12:25:03',50.00,NULL,NULL,NULL),(29,30,'Credit/Debit Card','Completed',NULL,'2026-10-08 12:32:05',500.00,'7788','Vince Paul','MasterCard'),(30,31,'Credit/Debit Card','Completed',NULL,'2026-10-08 12:33:17',500.00,'7788','Vince Paul','MasterCard'),(31,32,'Credit/Debit Card','Completed',NULL,'2026-10-08 12:47:12',50.00,'1223','Test','Visa');
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produce`
--

DROP TABLE IF EXISTS `produce`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produce` (
  `produce_id` int NOT NULL AUTO_INCREMENT,
  `farmer_id` int NOT NULL,
  `category_id` int NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `description` text,
  `price_per_unit` decimal(10,2) NOT NULL,
  `unit_type` varchar(20) NOT NULL,
  `stock_quantity` int NOT NULL,
  `harvest_date` date DEFAULT NULL,
  `status` varchar(50) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`produce_id`),
  KEY `farmer_id` (`farmer_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `produce_ibfk_1` FOREIGN KEY (`farmer_id`) REFERENCES `farmer` (`farmer_id`) ON DELETE CASCADE,
  CONSTRAINT `produce_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `produce_category` (`category_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produce`
--

LOCK TABLES `produce` WRITE;
/*!40000 ALTER TABLE `produce` DISABLE KEYS */;
INSERT INTO `produce` VALUES (3,1,1,'Fresh Carrots',NULL,50.00,'kg',0,NULL,'Available',NULL),(4,1,1,'Fresh Cabbage',NULL,70.00,'kg',0,NULL,'Available',NULL),(5,1,1,'Fresh Kiwi',NULL,500.00,'kg',166,NULL,'Available',NULL),(6,1,1,'Headphones',NULL,2000.00,'kg',0,NULL,'Available',NULL),(7,1,1,'Fresh Cabbage',NULL,20.00,'kg',500,NULL,'Available',NULL),(8,1,1,'Fresh Aubergene',NULL,50.00,'kg',77,NULL,'Available',NULL),(9,2,1,'Fresh Tomato',NULL,30.00,'kg',327,NULL,'Available',NULL),(10,1,1,'Fresh Carrots',NULL,50.00,'kg',100,NULL,'Available',NULL),(11,2,1,'Fresh Carrots',NULL,50.00,'kg',90,NULL,'Available',NULL),(12,2,1,'Fresh Mango',NULL,500.00,'kg',0,NULL,'Available',NULL),(13,3,1,'Fresh Eggs',NULL,50.00,'kg',99,NULL,'Available',NULL);
/*!40000 ALTER TABLE `produce` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produce_category`
--

DROP TABLE IF EXISTS `produce_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produce_category` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  `description` text,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produce_category`
--

LOCK TABLES `produce_category` WRITE;
/*!40000 ALTER TABLE `produce_category` DISABLE KEYS */;
INSERT INTO `produce_category` VALUES (1,'General Produce','Fresh farm items');
/*!40000 ALTER TABLE `produce_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saved_card`
--

DROP TABLE IF EXISTS `saved_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `saved_card` (
  `card_id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `card_holder_name` varchar(100) NOT NULL,
  `card_number_last4` varchar(4) NOT NULL,
  `card_type` varchar(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`card_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `saved_card_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saved_card`
--

LOCK TABLES `saved_card` WRITE;
/*!40000 ALTER TABLE `saved_card` DISABLE KEYS */;
INSERT INTO `saved_card` VALUES (1,4,'Samantha','4444','Visa','2026-09-29 00:37:50'),(2,2,'Penuel','1515','Visa','2026-09-29 00:44:01'),(3,3,'Adriel Sopera','7788','Visa','2026-09-29 01:14:05'),(4,4,'Sophia','0099','MasterCard','2026-09-29 22:44:29'),(5,4,'JC','1111','MasterCard','2026-09-30 01:21:38'),(6,3,'Vince Paul','7788','MasterCard','2026-10-08 12:31:39'),(7,7,'Test','1223','Visa','2026-10-08 12:46:24');
/*!40000 ALTER TABLE `saved_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_login`
--

DROP TABLE IF EXISTS `user_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_login` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `user_type` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_login`
--

LOCK TABLES `user_login` WRITE;
/*!40000 ALTER TABLE `user_login` DISABLE KEYS */;
INSERT INTO `user_login` VALUES (2,'Adriel','test','TEST','Farmer','2026-09-24 03:37:56'),(3,'Penuel','Penuel','TEST2','Consumer','2026-09-24 03:38:12'),(4,'Samantha','Samantha','samanthalasala@gmail.com','Consumer','2026-09-28 23:46:29'),(5,'vincent','vincent','vincent','Consumer','2026-09-29 00:18:09'),(6,'JC','JC','jc@gmail.com','Farmer','2026-09-29 00:19:28'),(9,'test','test','bleh','Farmer','2026-10-08 12:45:43');
/*!40000 ALTER TABLE `user_login` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-08 20:49:02
