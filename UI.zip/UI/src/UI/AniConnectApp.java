package UI;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.EventObject;
import java.util.List;

// 1. DOMAIN MODELS

abstract class User {
    private final int userId;
    private final String username;
    private final String email;
    private final int customerId;

    public User(int userId, String username, String email, int customerId) {
        this.userId = userId;
        this.username = username;
        this.email = email;
        this.customerId = customerId;
    }

    public int getUserId() { return userId; }
    public String getUsername() { return username; }
    public String getEmail() { return email; }
    public int getCustomerId() { return customerId; }

    public abstract String getRoleName();
    public abstract boolean canListProduce();
}

class ConsumerUser extends User {
    public ConsumerUser(int userId, String username, String email, int customerId) {
        super(userId, username, email, customerId);
    }

    @Override
    public String getRoleName() { return "Consumer"; }

    @Override
    public boolean canListProduce() { return false; }
}

class FarmerUser extends User {
    private final int farmerId;
    private final String farmName;

    public FarmerUser(int userId, String username, String email, int customerId, int farmerId, String farmName) {
        super(userId, username, email, customerId);
        this.farmerId = farmerId;
        this.farmName = farmName;
    }

    public int getFarmerId() { return farmerId; }
    public String getFarmName() { return farmName; }

    @Override
    public String getRoleName() { return "Farmer"; }

    @Override
    public boolean canListProduce() { return true; }
}

class Produce {
    private final int produceId;
    private final int farmerId;
    private final String name;
    private final double pricePerUnit;
    private double stockQuantity;
    private final String farmName;

    public Produce(int produceId, int farmerId, String name, double pricePerUnit, double stockQuantity, String farmName) {
        this.produceId = produceId;
        this.farmerId = farmerId;
        this.name = name;
        this.pricePerUnit = pricePerUnit;
        this.stockQuantity = stockQuantity;
        this.farmName = farmName;
    }

    public int getProduceId() { return produceId; }
    public int getFarmerId() { return farmerId; }
    public String getName() { return name; }
    public double getPricePerUnit() { return pricePerUnit; }
    public double getStockQuantity() { return stockQuantity; }
    public String getFarmName() { return farmName; }

    public boolean hasSufficientStock(double requestedQty) {
        return this.stockQuantity >= requestedQty;
    }
}

class SavedCard {
    private final int cardId;
    private final int customerId;
    private final String cardHolderName;
    private final String cardNumberLast4;
    private final String cardType;

    public SavedCard(int cardId, int customerId, String cardHolderName, String cardNumberLast4, String cardType) {
        this.cardId = cardId;
        this.customerId = customerId;
        this.cardHolderName = cardHolderName;
        this.cardNumberLast4 = cardNumberLast4;
        this.cardType = cardType;
    }

    public int getCardId() { return cardId; }
    public int getCustomerId() { return customerId; }
    public String getCardHolderName() { return cardHolderName; }
    public String getCardNumberLast4() { return cardNumberLast4; }
    public String getCardType() { return cardType; }

    @Override
    public String toString() {
        return cardType + " ending in **** " + cardNumberLast4 + " (" + cardHolderName + ")";
    }
}

class PaymentDetails {
    private final String method;
    private final String cardHolderName;
    private final String cardNumberLast4;
    private final String cardType;

    public PaymentDetails(String method, String cardHolderName, String cardNumber, String cardType) {
        this.method = method;
        this.cardHolderName = cardHolderName;
        this.cardNumberLast4 = (cardNumber != null && cardNumber.length() >= 4) 
                ? cardNumber.substring(cardNumber.length() - 4) 
                : cardNumber;
        this.cardType = cardType;
    }

    public String getMethod() { return method; }
    public String getCardHolderName() { return cardHolderName; }
    public String getCardNumberLast4() { return cardNumberLast4; }
    public String getCardType() { return cardType; }
}

class Order {
    private final User buyer;
    private final Produce produce;
    private final double quantity;
    private final double totalAmount;
    private PaymentDetails paymentDetails;

    public Order(User buyer, Produce produce, double quantity) {
        this.buyer = buyer;
        this.produce = produce;
        this.quantity = quantity;
        this.totalAmount = quantity * produce.getPricePerUnit();
    }

    public User getBuyer() { return buyer; }
    public Produce getProduce() { return produce; }
    public double getQuantity() { return quantity; }
    public double getTotalAmount() { return totalAmount; }
    public PaymentDetails getPaymentDetails() { return paymentDetails; }
    public void setPaymentDetails(PaymentDetails paymentDetails) { this.paymentDetails = paymentDetails; }
}

class FarmerOrderNotification {
    private final int orderId;
    private final String consumerName;
    private final String produceName;
    private final double quantity;
    private final double totalAmount;
    private final double remainingStock;
    private final String paymentMethod;
    private final String status;

    public FarmerOrderNotification(int orderId, String consumerName, String produceName, double quantity, double totalAmount, double remainingStock, String paymentMethod, String status) {
        this.orderId = orderId;
        this.consumerName = consumerName;
        this.produceName = produceName;
        this.quantity = quantity;
        this.totalAmount = totalAmount;
        this.remainingStock = remainingStock;
        this.paymentMethod = paymentMethod;
        this.status = status;
    }

    public int getOrderId() { return orderId; }
    public String getConsumerName() { return consumerName; }
    public String getProduceName() { return produceName; }
    public double getQuantity() { return quantity; }
    public double getTotalAmount() { return totalAmount; }
    public double getRemainingStock() { return remainingStock; }
    public String getPaymentMethod() { return paymentMethod; }
    public String getStatus() { return status; }
}

// 2. ABSTRACTION CONTRACTS

interface UserDAO {
    boolean registerUser(String username, String password, String email, String role);
    User validateUser(String username, String password);
}

interface ProduceDAO {
    boolean saveProduce(int farmerId, String name, double price, double quantity);
    List<Produce> fetchAvailableProduce();
    boolean processOrderTransaction(Order order);
    List<FarmerOrderNotification> fetchOrdersForFarmer(int farmerId);
    boolean updateOrderStatus(int orderId, String newStatus);

    boolean saveCustomerCard(int customerId, String cardHolderName, String cardNumber, String cardType);
    List<SavedCard> fetchSavedCardsForCustomer(int customerId);
    boolean verifyCardExists(int customerId, String last4Digits);
}

interface PaymentProcessor {
    boolean processPayment(double amount, PaymentDetails details);
}

class DirectPaymentGateway implements PaymentProcessor {
    @Override
    public boolean processPayment(double amount, PaymentDetails details) {
        return amount > 0;
    }
}

// 3. USER INTERFACE COMPONENTS

class FarmerReportDialog extends JDialog {
    public FarmerReportDialog(Frame parent, Order order, double remainingStock) {
        super(parent, "New Purchase Order Report", true);
        setSize(450, 350);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(10, 10));

        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(46, 139, 87));
        JLabel titleLabel = new JLabel("INCOMING PURCHASE REPORT");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);

        JPanel detailsPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        detailsPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        detailsPanel.add(new JLabel("Customer Name:"));
        detailsPanel.add(new JLabel(order.getBuyer().getUsername()));

        detailsPanel.add(new JLabel("Produce Sold:"));
        detailsPanel.add(new JLabel(order.getProduce().getName()));

        detailsPanel.add(new JLabel("Quantity Bought:"));
        detailsPanel.add(new JLabel(order.getQuantity() + " Kg"));

        detailsPanel.add(new JLabel("Payment Received:"));
        detailsPanel.add(new JLabel("₱" + String.format("%.2f", order.getTotalAmount())));

        detailsPanel.add(new JLabel("Payment Method:"));
        detailsPanel.add(new JLabel(order.getPaymentDetails() != null ? order.getPaymentDetails().getMethod() : "Cash on Delivery"));

        detailsPanel.add(new JLabel("Stock Remaining:"));
        JLabel stockLabel = new JLabel(remainingStock + " Kg");
        stockLabel.setFont(new Font("Arial", Font.BOLD, 14));
        stockLabel.setForeground(new Color(211, 84, 0));
        detailsPanel.add(stockLabel);

        JButton closeBtn = new JButton("Acknowledge Report");
        closeBtn.setBackground(new Color(40, 116, 166));
        closeBtn.setForeground(Color.WHITE);
        closeBtn.addActionListener(e -> dispose());

        JPanel bottomPanel = new JPanel();
        bottomPanel.add(closeBtn);

        add(headerPanel, BorderLayout.NORTH);
        add(detailsPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
    }
}

class LoginDialog extends JDialog {
    private final JTextField userField = new JTextField(10);
    private final JPasswordField passField = new JPasswordField(10);
    private final JTextField emailField = new JTextField(10);
    private final JComboBox<String> roleCombo = new JComboBox<>(new String[]{"Consumer", "Farmer"});
    private boolean succeeded = false;
    private User authenticatedUser;

    private final UserDAO userDAO;

    public LoginDialog(Frame parent, UserDAO userDAO) {
        super(parent, "AniConnect - Authentication Portal", true);
        this.userDAO = userDAO;

        setSize(420, 300);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        panel.add(new JLabel("Account Role:"));
        panel.add(roleCombo);
        panel.add(new JLabel("Username:"));
        panel.add(userField);
        panel.add(new JLabel("Password:"));
        panel.add(passField);
        panel.add(new JLabel("Email (for Registration):"));
        panel.add(emailField);

        JButton loginBtn = new JButton("Login");
        loginBtn.setBackground(new Color(40, 116, 166));
        loginBtn.setForeground(Color.WHITE);

        JButton registerBtn = new JButton("Create Account");
        registerBtn.setBackground(new Color(46, 139, 87));
        registerBtn.setForeground(Color.WHITE);

        panel.add(loginBtn);
        panel.add(registerBtn);

        add(panel, BorderLayout.CENTER);

        loginBtn.addActionListener(e -> handleLogin());
        registerBtn.addActionListener(e -> handleRegistration());
    }

    private void handleLogin() {
        String user = userField.getText().trim();
        String pass = new String(passField.getPassword());

        if (user.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both username and password.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        User u = userDAO.validateUser(user, pass);
        if (u != null) {
            succeeded = true;
            authenticatedUser = u;
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials or account does not exist.", "Login Failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleRegistration() {
        String user = userField.getText().trim();
        String pass = new String(passField.getPassword());
        String email = emailField.getText().trim();
        String role = (String) roleCombo.getSelectedItem();

        if (user.isEmpty() || pass.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields to register.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (userDAO.registerUser(user, pass, email, role)) {
            JOptionPane.showMessageDialog(this, "Account created successfully! Logging in...", "Success", JOptionPane.INFORMATION_MESSAGE);
            succeeded = true;
            authenticatedUser = userDAO.validateUser(user, pass);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Username or Email already exists.", "Registration Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isSucceeded() { return succeeded; }
    public User getAuthenticatedUser() { return authenticatedUser; }
}

class SaveCardDialog extends JDialog {
    private final JTextField cardHolderField = new JTextField(15);
    private final JTextField cardNumberField = new JTextField(16);
    private final JComboBox<String> cardTypeCombo;
    private boolean saved = false;

    public SaveCardDialog(Dialog parent, ProduceDAO produceDAO, int customerId, String defaultType) {
        super(parent, "Register New " + defaultType + " Card", true);
        setSize(380, 220);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(10, 10));

        cardTypeCombo = new JComboBox<>(new String[]{"Visa", "MasterCard", "JCB"});
        if (defaultType != null) {
            cardTypeCombo.setSelectedItem(defaultType);
        }

        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        panel.add(new JLabel("Card Type:"));
        panel.add(cardTypeCombo);
        panel.add(new JLabel("Cardholder Name:"));
        panel.add(cardHolderField);
        panel.add(new JLabel("16-Digit Card Number:"));
        panel.add(cardNumberField);

        JButton saveBtn = new JButton("Save & Register Card");
        saveBtn.setBackground(new Color(46, 139, 87));
        saveBtn.setForeground(Color.WHITE);

        saveBtn.addActionListener(e -> {
            String name = cardHolderField.getText().trim();
            String num = cardNumberField.getText().trim();
            String type = (String) cardTypeCombo.getSelectedItem();

            if (name.isEmpty() || num.length() < 12) {
                JOptionPane.showMessageDialog(this, "Please enter a valid cardholder name and 12-16 digit card number.", "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (produceDAO.saveCustomerCard(customerId, name, num, type)) {
                JOptionPane.showMessageDialog(this, "Card registered successfully in database!", "Card Saved", JOptionPane.INFORMATION_MESSAGE);
                saved = true;
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to register card in database.", "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(new JLabel());
        panel.add(saveBtn);

        add(panel, BorderLayout.CENTER);
    }

    public boolean isSaved() { return saved; }
}

class OrderQuantityDialog extends JDialog {
    private final JTextField qtyField;
    private final JLabel totalLabel;
    private final Produce produce;
    private boolean confirmed = false;
    private double selectedQuantity = 0;

    public OrderQuantityDialog(Frame parent, Produce produce) {
        super(parent, "Buy " + produce.getName(), true);
        this.produce = produce;

        setSize(420, 280);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(10, 10));

        JPanel infoPanel = new JPanel(new GridLayout(4, 2, 12, 12));
        infoPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 10, 20));

        JLabel itemLabelHeading = new JLabel("Produce Item:");
        JLabel itemValueLabel = new JLabel(produce.getName());
        itemLabelHeading.setFont(new Font("Arial", Font.BOLD, 14));
        itemValueLabel.setFont(new Font("Arial", Font.PLAIN, 14));

        JLabel priceLabelHeading = new JLabel("Price per Kg:");
        JLabel priceValueLabel = new JLabel("₱" + produce.getPricePerUnit());
        priceLabelHeading.setFont(new Font("Arial", Font.BOLD, 14));
        priceValueLabel.setFont(new Font("Arial", Font.PLAIN, 14));

        JLabel stockLabelHeading = new JLabel("Available Stock:");
        JLabel stockValueLabel = new JLabel(produce.getStockQuantity() + " Kg");
        stockLabelHeading.setFont(new Font("Arial", Font.BOLD, 14));
        stockValueLabel.setFont(new Font("Arial", Font.PLAIN, 14));

        JLabel qtyLabelHeading = new JLabel("Type Quantity (Kg):");
        qtyLabelHeading.setFont(new Font("Arial", Font.BOLD, 14));

        qtyField = new JTextField("1.0");
        qtyField.setFont(new Font("Arial", Font.BOLD, 18));
        qtyField.setHorizontalAlignment(JTextField.CENTER);
        qtyField.setPreferredSize(new Dimension(120, 35));

        infoPanel.add(itemLabelHeading);
        infoPanel.add(itemValueLabel);
        infoPanel.add(priceLabelHeading);
        infoPanel.add(priceValueLabel);
        infoPanel.add(stockLabelHeading);
        infoPanel.add(stockValueLabel);
        infoPanel.add(qtyLabelHeading);
        infoPanel.add(qtyField);

        totalLabel = new JLabel("₱" + String.format("%.2f", produce.getPricePerUnit()));
        totalLabel.setFont(new Font("Arial", Font.BOLD, 18));
        totalLabel.setForeground(new Color(211, 84, 0));

        JPanel bottomPanel = new JPanel(new BorderLayout(10, 10));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 15, 20));

        JPanel totalPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel totalTitleLabel = new JLabel("Total Amount: ");
        totalTitleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        totalPanel.add(totalTitleLabel);
        totalPanel.add(totalLabel);

        JButton proceedBtn = new JButton("Proceed to Payment");
        proceedBtn.setFont(new Font("Arial", Font.BOLD, 14));
        proceedBtn.setPreferredSize(new Dimension(0, 40));
        proceedBtn.setBackground(new Color(46, 139, 87));
        proceedBtn.setForeground(Color.WHITE);

        bottomPanel.add(totalPanel, BorderLayout.NORTH);
        bottomPanel.add(proceedBtn, BorderLayout.SOUTH);

        qtyField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateTotal(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateTotal(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateTotal(); }
        });

        proceedBtn.addActionListener(e -> {
            try {
                selectedQuantity = Double.parseDouble(qtyField.getText().trim());

                if (selectedQuantity <= 0) {
                    JOptionPane.showMessageDialog(this, "Quantity must be greater than zero.", "Invalid Quantity", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (selectedQuantity > produce.getStockQuantity()) {
                    JOptionPane.showMessageDialog(this, "Entered quantity exceeds available stock (" + produce.getStockQuantity() + " Kg).", "Stock Limit Exceeded", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                confirmed = true;
                dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid numeric quantity.", "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        add(infoPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void updateTotal() {
        try {
            double qty = Double.parseDouble(qtyField.getText().trim());
            if (qty > 0) {
                double total = qty * produce.getPricePerUnit();
                totalLabel.setText("₱" + String.format("%.2f", total));
            } else {
                totalLabel.setText("₱0.00");
            }
        } catch (NumberFormatException e) {
            totalLabel.setText("₱0.00");
        }
    }

    public boolean isConfirmed() { return confirmed; }
    public double getSelectedQuantity() { return selectedQuantity; }
}

// POP-UP DIALOG 2: CARD BRAND SELECTOR (VISA, MASTERCARD, JCB)
class CardBrandSelectionDialog extends JDialog {
    private final ProduceDAO produceDAO;
    private final User buyer;
    private SavedCard selectedSavedCard = null;
    private boolean confirmed = false;

    private final JPanel savedCardsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
    private final JLabel selectedStatusLabel = new JLabel("Click a card brand button below", SwingConstants.CENTER);

    public CardBrandSelectionDialog(Dialog parent, ProduceDAO produceDAO, User buyer) {
        super(parent, "Select Credit/Debit Card Brand", true);
        this.produceDAO = produceDAO;
        this.buyer = buyer;

        setSize(600, 420);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(15, 15));

        JPanel headerPanel = new JPanel(new GridLayout(2, 1));
        headerPanel.setBackground(new Color(26, 82, 118));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("Choose Your Card Brand", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(Color.WHITE);

        selectedStatusLabel.setFont(new Font("Arial", Font.ITALIC, 13));
        selectedStatusLabel.setForeground(Color.YELLOW);

        headerPanel.add(titleLabel);
        headerPanel.add(selectedStatusLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Center Option Cards (Visa, MasterCard, JCB)
        JPanel brandsGrid = new JPanel(new GridLayout(1, 3, 15, 0));
        brandsGrid.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        JButton visaBtn = createBrandButton("VISA", "💳 Blue Card", new Color(26, 82, 118));
        JButton mastercardBtn = createBrandButton("MasterCard", "💳 Red/Orange", new Color(180, 50, 40));
        JButton jcbBtn = createBrandButton("JCB", "💳 Green/Gold", new Color(40, 116, 100));

        brandsGrid.add(visaBtn);
        brandsGrid.add(mastercardBtn);
        brandsGrid.add(jcbBtn);

        JPanel centerContainer = new JPanel(new BorderLayout(10, 10));
        centerContainer.add(brandsGrid, BorderLayout.NORTH);

        savedCardsPanel.setBorder(BorderFactory.createTitledBorder("Matching Saved Cards"));
        savedCardsPanel.setPreferredSize(new Dimension(550, 140));
        JScrollPane scrollPane = new JScrollPane(savedCardsPanel);

        centerContainer.add(scrollPane, BorderLayout.CENTER);
        add(centerContainer, BorderLayout.CENTER);

        visaBtn.addActionListener(e -> loadBrandCards("Visa"));
        mastercardBtn.addActionListener(e -> loadBrandCards("MasterCard"));
        jcbBtn.addActionListener(e -> loadBrandCards("JCB"));

        // Bottom Bar
        JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));

        JButton registerBtn = new JButton("+ Register New Card");
        registerBtn.setBackground(new Color(100, 110, 120));
        registerBtn.setForeground(Color.WHITE);

        JButton confirmBtn = new JButton("Use Selected Card");
        confirmBtn.setFont(new Font("Arial", Font.BOLD, 13));
        confirmBtn.setBackground(new Color(46, 139, 87));
        confirmBtn.setForeground(Color.WHITE);

        registerBtn.addActionListener(e -> {
            SaveCardDialog saveDlg = new SaveCardDialog(this, produceDAO, buyer.getCustomerId(), "Visa");
            saveDlg.setVisible(true);
            if (saveDlg.isSaved()) {
                loadBrandCards("Visa");
            }
        });

        confirmBtn.addActionListener(e -> {
            if (selectedSavedCard == null) {
                JOptionPane.showMessageDialog(this, "Please click on a card tile to select it.", "Selection Required", JOptionPane.ERROR_MESSAGE);
                return;
            }
            confirmed = true;
            dispose();
        });

        bottomBar.add(registerBtn);
        bottomBar.add(confirmBtn);
        add(bottomBar, BorderLayout.SOUTH);
    }

    private JButton createBrandButton(String brandName, String sub, Color bg) {
        JButton btn = new JButton();
        btn.setLayout(new GridLayout(2, 1));
        btn.setPreferredSize(new Dimension(160, 60));
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JLabel title = new JLabel(brandName, SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 16));
        title.setForeground(Color.WHITE);

        JLabel subtitle = new JLabel(sub, SwingConstants.CENTER);
        subtitle.setFont(new Font("Arial", Font.PLAIN, 11));
        subtitle.setForeground(new Color(230, 230, 230));

        btn.add(title);
        btn.add(subtitle);
        return btn;
    }

    private void loadBrandCards(String brand) {
        savedCardsPanel.removeAll();
        List<SavedCard> allCards = produceDAO.fetchSavedCardsForCustomer(buyer.getCustomerId());

        int count = 0;
        for (SavedCard card : allCards) {
            if (brand.equalsIgnoreCase(card.getCardType())) {
                count++;
                JButton tile = createCardTile(card);
                savedCardsPanel.add(tile);
            }
        }

        if (count == 0) {
            JLabel emptyLbl = new JLabel("No registered " + brand + " cards found. Click '+ Register New Card' to add one.");
            emptyLbl.setFont(new Font("Arial", Font.ITALIC, 12));
            savedCardsPanel.add(emptyLbl);
        }

        selectedStatusLabel.setText("Selected Brand: " + brand + " (" + count + " card(s) found)");
        savedCardsPanel.revalidate();
        savedCardsPanel.repaint();
    }

    private JButton createCardTile(SavedCard card) {
        JButton tile = new JButton();
        tile.setPreferredSize(new Dimension(160, 90));
        tile.setLayout(new GridLayout(3, 1));
        tile.setFocusPainted(false);
        tile.setCursor(new Cursor(Cursor.HAND_CURSOR));

        Color bg = "Visa".equalsIgnoreCase(card.getCardType()) ? new Color(26, 82, 118) :
                   "MasterCard".equalsIgnoreCase(card.getCardType()) ? new Color(180, 50, 40) :
                   new Color(40, 116, 100);

        if (selectedSavedCard != null && selectedSavedCard.getCardId() == card.getCardId()) {
            tile.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));
        } else {
            tile.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        }

        tile.setBackground(bg);

        JLabel typeLbl = new JLabel("  " + card.getCardType().toUpperCase(), SwingConstants.LEFT);
        typeLbl.setFont(new Font("Arial", Font.BOLD, 12));
        typeLbl.setForeground(Color.WHITE);

        JLabel numLbl = new JLabel("**** " + card.getCardNumberLast4(), SwingConstants.CENTER);
        numLbl.setFont(new Font("Monospaced", Font.BOLD, 13));
        numLbl.setForeground(Color.WHITE);

        JLabel nameLbl = new JLabel("  " + card.getCardHolderName(), SwingConstants.LEFT);
        nameLbl.setFont(new Font("Arial", Font.PLAIN, 10));
        nameLbl.setForeground(Color.LIGHT_GRAY);

        tile.add(typeLbl);
        tile.add(numLbl);
        tile.add(nameLbl);

        tile.addActionListener(e -> {
            selectedSavedCard = card;
            selectedStatusLabel.setText("Selected Card: " + card.toString());
            loadBrandCards(card.getCardType());
        });

        return tile;
    }

    public boolean isConfirmed() { return confirmed; }
    public SavedCard getSelectedSavedCard() { return selectedSavedCard; }
}

// POP-UP DIALOG 1: MAIN PAYMENT METHOD SELECTOR
class PaymentDialog extends JDialog {
    private boolean confirmed = false;
    private PaymentDetails paymentDetails;
    private final ProduceDAO produceDAO;
    private final User buyer;

    private String selectedMethod = "Cash on Delivery";
    private SavedCard chosenCard = null;

    private final JLabel selectedStatusLabel = new JLabel("Selected: Cash on Delivery", SwingConstants.CENTER);

    public PaymentDialog(Frame parent, double amount, ProduceDAO produceDAO, User buyer) {
        super(parent, "Select Payment Method - Total: ₱" + String.format("%.2f", amount), true);
        this.produceDAO = produceDAO;
        this.buyer = buyer;

        setSize(550, 320);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(15, 15));

        JPanel headerPanel = new JPanel(new GridLayout(2, 1));
        headerPanel.setBackground(new Color(40, 116, 166));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("Choose Payment Method", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);

        selectedStatusLabel.setFont(new Font("Arial", Font.ITALIC, 13));
        selectedStatusLabel.setForeground(Color.YELLOW);

        headerPanel.add(titleLabel);
        headerPanel.add(selectedStatusLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Center Panel: Graphical Option Buttons
        JPanel mainOptionPanel = new JPanel(new GridLayout(1, 2, 20, 0));
        mainOptionPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JButton codCardBtn = createPaymentMethodCard("Cash on Delivery", "💵 Pay upon produce receipt", new Color(46, 139, 87));
        JButton cardCardBtn = createPaymentMethodCard("Credit / Debit Card", "💳 Visa, MasterCard, JCB", new Color(40, 116, 166));

        mainOptionPanel.add(codCardBtn);
        mainOptionPanel.add(cardCardBtn);

        add(mainOptionPanel, BorderLayout.CENTER);

        // COD Selection Action
        codCardBtn.addActionListener(e -> {
            selectedMethod = "Cash on Delivery";
            chosenCard = null;
            selectedStatusLabel.setText("Selected: Cash on Delivery");
        });

        // Credit/Debit Card Selection Action - Opens Dedicated Pop-Up Step 2
        cardCardBtn.addActionListener(e -> {
            CardBrandSelectionDialog brandDlg = new CardBrandSelectionDialog(this, produceDAO, buyer);
            brandDlg.setVisible(true);

            if (brandDlg.isConfirmed() && brandDlg.getSelectedSavedCard() != null) {
                selectedMethod = "Credit/Debit Card";
                chosenCard = brandDlg.getSelectedSavedCard();
                selectedStatusLabel.setText("Selected: " + chosenCard.toString());
            }
        });

        // Bottom Bar
        JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));

        JButton confirmBtn = new JButton("Confirm & Pay ₱" + String.format("%.2f", amount));
        confirmBtn.setFont(new Font("Arial", Font.BOLD, 14));
        confirmBtn.setBackground(new Color(46, 139, 87));
        confirmBtn.setForeground(Color.WHITE);

        confirmBtn.addActionListener(e -> {
            if ("Credit/Debit Card".equals(selectedMethod)) {
                if (chosenCard == null) {
                    JOptionPane.showMessageDialog(this, "Please click 'Credit / Debit Card' to select a card brand and card first.", "Card Selection Required", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (!produceDAO.verifyCardExists(buyer.getCustomerId(), chosenCard.getCardNumberLast4())) {
                    JOptionPane.showMessageDialog(this, "Card verification failed in database.", "Database Verification Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                paymentDetails = new PaymentDetails(
                        selectedMethod,
                        chosenCard.getCardHolderName(),
                        chosenCard.getCardNumberLast4(),
                        chosenCard.getCardType()
                );
            } else {
                paymentDetails = new PaymentDetails(selectedMethod, null, null, null);
            }
            confirmed = true;
            dispose();
        });

        bottomBar.add(confirmBtn);
        add(bottomBar, BorderLayout.SOUTH);
    }

    private JButton createPaymentMethodCard(String title, String subtitle, Color themeColor) {
        JButton card = new JButton();
        card.setLayout(new GridLayout(2, 1));
        card.setPreferredSize(new Dimension(220, 80));
        card.setBackground(themeColor);
        card.setFocusPainted(false);
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JLabel mainLabel = new JLabel(title, SwingConstants.CENTER);
        mainLabel.setFont(new Font("Arial", Font.BOLD, 15));
        mainLabel.setForeground(Color.WHITE);

        JLabel subLabel = new JLabel(subtitle, SwingConstants.CENTER);
        subLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        subLabel.setForeground(new Color(230, 230, 230));

        card.add(mainLabel);
        card.add(subLabel);

        return card;
    }

    public boolean isConfirmed() { return confirmed; }
    public PaymentDetails getPaymentDetails() { return paymentDetails; }
}

class ButtonRenderer extends JButton implements TableCellRenderer {
    public ButtonRenderer() {
        setOpaque(true);
        setBackground(new Color(46, 139, 87));
        setForeground(Color.WHITE);
        setFocusPainted(false);
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        setText((value == null) ? "Mark as Finished" : value.toString());
        return this;
    }
}

class ButtonEditor extends AbstractCellEditor implements TableCellEditor {
    private final JButton button;
    private String label;
    private boolean isPushed;
    private final JTable table;
    private final ProduceDAO produceDAO;
    private final Runnable refreshCallback;

    public ButtonEditor(JCheckBox checkBox, JTable table, ProduceDAO produceDAO, Runnable refreshCallback) {
        this.table = table;
        this.produceDAO = produceDAO;
        this.refreshCallback = refreshCallback;

        button = new JButton();
        button.setOpaque(true);
        button.setBackground(new Color(46, 139, 87));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);

        button.addActionListener(e -> fireEditingStopped());
    }

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
        label = (value == null) ? "Mark as Finished" : value.toString();
        button.setText(label);
        isPushed = true;
        return button;
    }

    @Override
    public Object getCellEditorValue() {
        if (isPushed) {
            int row = table.getSelectedRow();
            if (row != -1) {
                int orderId = (int) table.getValueAt(row, 0);
                if (produceDAO.updateOrderStatus(orderId, "Finished")) {
                    JOptionPane.showMessageDialog(button, "Order #" + orderId + " marked as Finished!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    SwingUtilities.invokeLater(refreshCallback);
                } else {
                    JOptionPane.showMessageDialog(button, "Failed to update order status.", "Database Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
        isPushed = false;
        return label;
    }

    @Override
    public boolean isCellEditable(EventObject anEvent) { return true; }
}

public class AniConnectApp extends JFrame {

    private final User currentUser;
    private final UserDAO userDAO;
    private final ProduceDAO produceDAO;
    private final PaymentProcessor paymentProcessor;

    private JTextArea sequenceLogArea;
    private DefaultTableModel produceTableModel;
    private DefaultTableModel farmerOrdersTableModel;
    private JTable produceTable;

    private JTextField itemTitleField, itemPriceField, itemQtyField, farmerNameField;

    public AniConnectApp(User user, UserDAO userDAO, ProduceDAO produceDAO, PaymentProcessor paymentProcessor) {
        this.currentUser = user;
        this.userDAO = userDAO;
        this.produceDAO = produceDAO;
        this.paymentProcessor = paymentProcessor;

        setTitle("AniConnect Platform (Logged in as: " + user.getUsername() + " [" + user.getRoleName() + "])");
        setSize(1150, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        setupHeader();
        add(createSequenceLogPanel(), BorderLayout.EAST);

        if (currentUser.canListProduce()) {
            JTabbedPane tabbedPane = new JTabbedPane();
            tabbedPane.addTab("Farmer Portal (Add Produce)", createFarmerPanel());
            tabbedPane.addTab("Marketplace Storefront (Buy Produce)", createConsumerPanel());
            add(tabbedPane, BorderLayout.CENTER);

            farmerNameField.setText(currentUser.getUsername());
            refreshProduceTable();
            refreshFarmerOrdersTable();
        } else {
            add(createConsumerPanel(), BorderLayout.CENTER);
            refreshProduceTable();
            triggerBrowseProduce();
        }
    }

    private void setupHeader() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(40, 116, 166));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        JPanel textPanel = new JPanel(new GridLayout(2, 1));
        textPanel.setOpaque(false);

        JLabel titleLabel = new JLabel("AniConnect Direct E-Commerce Platform");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);

        JLabel descLabel = new JLabel("Welcome, " + currentUser.getUsername() + "! Role: " + currentUser.getRoleName());
        descLabel.setFont(new Font("Arial", Font.ITALIC, 12));
        descLabel.setForeground(Color.WHITE);

        textPanel.add(titleLabel);
        textPanel.add(descLabel);

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBackground(new Color(192, 57, 43));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setFocusPainted(false);

        logoutBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to log out?", "Logout", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                this.dispose();
                LoginDialog loginDlg = new LoginDialog(null, userDAO);
                loginDlg.setVisible(true);

                if (loginDlg.isSucceeded()) {
                    new AniConnectApp(loginDlg.getAuthenticatedUser(), userDAO, produceDAO, paymentProcessor).setVisible(true);
                } else {
                    System.exit(0);
                }
            }
        });

        headerPanel.add(textPanel, BorderLayout.CENTER);
        headerPanel.add(logoutBtn, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);
    }

    private JPanel createFarmerPanel() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel formPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createTitledBorder("Step 1: Farmer Add Produce"));

        farmerNameField = new JTextField();
        farmerNameField.setEditable(false);
        itemTitleField = new JTextField("Fresh Carrots");
        itemPriceField = new JTextField("50.0");
        itemQtyField = new JTextField("100.0");

        formPanel.add(new JLabel("Farmer Account:"));
        formPanel.add(farmerNameField);
        formPanel.add(new JLabel("Produce Name:"));
        formPanel.add(itemTitleField);
        formPanel.add(new JLabel("Price per Kg (₱):"));
        formPanel.add(itemPriceField);
        formPanel.add(new JLabel("Quantity (Kg):"));
        formPanel.add(itemQtyField);

        JButton addBtn = new JButton("Submit Produce Listing");
        addBtn.setBackground(new Color(46, 139, 87));
        addBtn.setForeground(Color.WHITE);
        formPanel.add(addBtn);

        mainPanel.add(formPanel, BorderLayout.NORTH);

        farmerOrdersTableModel = new DefaultTableModel(
            new String[]{"Order ID", "Customer Name", "Produce Purchased", "Qty Bought (Kg)", "Payment Amount (₱)", "Stock Remaining (Kg)", "Payment Method", "Status", "Action"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 8;
            }
        };

        JTable farmerOrdersTable = new JTable(farmerOrdersTableModel);
        farmerOrdersTable.setRowHeight(30);

        farmerOrdersTable.getColumn("Action").setCellRenderer(new ButtonRenderer());
        farmerOrdersTable.getColumn("Action").setCellEditor(new ButtonEditor(new JCheckBox(), farmerOrdersTable, produceDAO, this::refreshFarmerOrdersTable));

        JScrollPane scrollPane = new JScrollPane(farmerOrdersTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Customer Purchase Reports for " + currentUser.getUsername()));

        mainPanel.add(scrollPane, BorderLayout.CENTER);

        addBtn.addActionListener(e -> {
            try {
                String title = itemTitleField.getText().trim();
                double price = Double.parseDouble(itemPriceField.getText().trim());
                double qty = Double.parseDouble(itemQtyField.getText().trim());

                if (title.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please enter a produce name.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (currentUser instanceof FarmerUser) {
                    FarmerUser farmer = (FarmerUser) currentUser;
                    logSequence("1. Farmer calls saveProduce()");

                    if (produceDAO.saveProduce(farmer.getFarmerId(), title, price, qty)) {
                        logSequence("2. Executed SQL: INSERT INTO produce");
                        logSequence("3. Database returned SUCCESS");
                        JOptionPane.showMessageDialog(this, "Produce successfully saved!", "Success", JOptionPane.INFORMATION_MESSAGE);

                        itemTitleField.setText("");
                        refreshProduceTable();
                    } else {
                        JOptionPane.showMessageDialog(this, "Failed to save produce to database.", "Database Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid number inputs for price or quantity.", "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        return mainPanel;
    }

    private JPanel createConsumerPanel() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        produceTableModel = new DefaultTableModel(new String[]{"ID", "Produce Name", "Price/Kg (₱)", "Available (Kg)", "Farmer"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        produceTable = new JTable(produceTableModel);
        produceTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        produceTable.setRowHeight(25);

        JScrollPane catalogScroll = new JScrollPane(produceTable);
        catalogScroll.setBorder(BorderFactory.createTitledBorder("Steps 9-12: Produce Marketplace Catalog (Click row to buy)"));

        JPanel orderPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        orderPanel.setBorder(BorderFactory.createTitledBorder("Steps 13-18: Pre-Order Selection"));

        JButton preOrderBtn = new JButton("Buy Selected Produce");
        preOrderBtn.setBackground(new Color(211, 84, 0));
        preOrderBtn.setForeground(Color.WHITE);

        orderPanel.add(preOrderBtn);

        mainPanel.add(catalogScroll, BorderLayout.CENTER);
        mainPanel.add(orderPanel, BorderLayout.SOUTH);

        produceTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    handleProduceSelectionAndOrder();
                }
            }
        });

        preOrderBtn.addActionListener(e -> handleProduceSelectionAndOrder());

        return mainPanel;
    }

    private void handleProduceSelectionAndOrder() {
        int selectedRow = produceTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please click and select an item from the table catalog first.", "No Item Selected", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int produceId = (Integer) produceTableModel.getValueAt(selectedRow, 0);

        Produce selectedProduce = null;
        List<Produce> produceList = produceDAO.fetchAvailableProduce();
        for (Produce p : produceList) {
            if (p.getProduceId() == produceId) {
                selectedProduce = p;
                break;
            }
        }

        if (selectedProduce == null) return;

        OrderQuantityDialog qtyDialog = new OrderQuantityDialog(this, selectedProduce);
        qtyDialog.setVisible(true);

        if (!qtyDialog.isConfirmed()) return;

        double selectedQty = qtyDialog.getSelectedQuantity();

        if (!selectedProduce.hasSufficientStock(selectedQty)) {
            JOptionPane.showMessageDialog(this, "Requested quantity exceeds available stock!", "Stock Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Order order = new Order(currentUser, selectedProduce, selectedQty);

        PaymentDialog payDialog = new PaymentDialog(this, order.getTotalAmount(), produceDAO, currentUser);
        payDialog.setVisible(true);

        if (!payDialog.isConfirmed()) return;

        order.setPaymentDetails(payDialog.getPaymentDetails());

        logSequence("13. Buyer calls selectItems()");
        logSequence("14. Buyer calls requestPreOrder()");
        logSequence("15. Verifying database saved card and authorizing payment via " + order.getPaymentDetails().getMethod() + "...");

        boolean success = paymentProcessor.processPayment(order.getTotalAmount(), order.getPaymentDetails());

        if (success) {
            logSequence("16. Executing transaction via ProduceDAO...");
            if (produceDAO.processOrderTransaction(order)) {
                logSequence("17. Transaction committed to database!");
                
                double remainingStock = selectedProduce.getStockQuantity() - selectedQty;

                JOptionPane.showMessageDialog(this, "Order Placed & Recorded!\nItem: " + selectedProduce.getName() + "\nQuantity: " + selectedQty + " Kg\nPayment Method: " + order.getPaymentDetails().getMethod() + "\nTotal: ₱" + order.getTotalAmount(), "Order Confirmation", JOptionPane.INFORMATION_MESSAGE);

                FarmerReportDialog reportDlg = new FarmerReportDialog(this, order, remainingStock);
                reportDlg.setVisible(true);

                refreshProduceTable();
                refreshFarmerOrdersTable();
            } else {
                JOptionPane.showMessageDialog(this, "Order processing failed.", "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void triggerBrowseProduce() {
        logSequence("9. Buyer calls browseProduce()");
        logSequence("10. ProduceDAO executes SELECT query");
        logSequence("11. Database returns produce records");
        logSequence("12. UI displays available produce");
    }

    private void refreshProduceTable() {
        if (produceTableModel == null) return;

        produceTableModel.setRowCount(0);

        List<Produce> list = produceDAO.fetchAvailableProduce();

        for (Produce p : list) {
            produceTableModel.addRow(new Object[]{
                p.getProduceId(),
                p.getName(),
                p.getPricePerUnit(),
                p.getStockQuantity(),
                p.getFarmName()
            });
        }
    }

    private void refreshFarmerOrdersTable() {
        if (farmerOrdersTableModel == null || !(currentUser instanceof FarmerUser)) return;

        FarmerUser farmer = (FarmerUser) currentUser;
        farmerOrdersTableModel.setRowCount(0);

        List<FarmerOrderNotification> notifications = produceDAO.fetchOrdersForFarmer(farmer.getFarmerId());

        for (FarmerOrderNotification n : notifications) {
            farmerOrdersTableModel.addRow(new Object[]{
                n.getOrderId(),
                n.getConsumerName(),
                n.getProduceName(),
                n.getQuantity(),
                n.getTotalAmount(),
                n.getRemainingStock(),
                n.getPaymentMethod(),
                n.getStatus(),
                "Mark as Finished"
            });
        }
    }

    private JPanel createSequenceLogPanel() {
        JPanel logPanel = new JPanel(new BorderLayout());
        logPanel.setPreferredSize(new Dimension(340, 0));
        logPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Sequence Diagram Execution Log", TitledBorder.LEFT, TitledBorder.TOP));

        sequenceLogArea = new JTextArea();
        sequenceLogArea.setEditable(false);
        sequenceLogArea.setFont(new Font("Monospaced", Font.PLAIN, 11));
        sequenceLogArea.setBackground(new Color(245, 245, 245));

        JScrollPane scrollPane = new JScrollPane(sequenceLogArea);
        logPanel.add(scrollPane, BorderLayout.CENTER);

        JButton clearBtn = new JButton("Clear Log");
        clearBtn.addActionListener(e -> sequenceLogArea.setText(""));
        logPanel.add(clearBtn, BorderLayout.SOUTH);

        return logPanel;
    }

    private void logSequence(String message) {
        if (sequenceLogArea != null) {
            sequenceLogArea.append(message + "\n");
            sequenceLogArea.setCaretPosition(sequenceLogArea.getDocument().getLength());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            DatabaseManager dbManager = new DatabaseManager();
            PaymentProcessor paymentProcessor = new DirectPaymentGateway();

            LoginDialog loginDlg = new LoginDialog(null, dbManager);
            loginDlg.setVisible(true);

            if (loginDlg.isSucceeded()) {
                User authenticatedUser = loginDlg.getAuthenticatedUser();
                AniConnectApp app = new AniConnectApp(authenticatedUser, dbManager, dbManager, paymentProcessor);
                app.setVisible(true);
            } else {
                System.exit(0);
            }
        });
    }
}