package UI;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseManager implements UserDAO, ProduceDAO {

    private static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/quennie?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "insurgentbrutha123";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found! Ensure the JAR is added to classpath.");
        }
    }

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
    }

    @Override
    public boolean registerUser(String username, String password, String email, String role) {
        String insertLoginSQL = "INSERT INTO user_login (username, password_hash, email, user_type) VALUES (?, ?, ?, ?)";
        String insertCustSQL = "INSERT INTO customer (user_id, first_name, last_name) VALUES (?, ?, 'User')";
        String insertFarmerSQL = "INSERT INTO farmer (user_id, farm_name, owner_name) VALUES (?, ?, ?)";

        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false);

            int userId;
            try (PreparedStatement pstmt = conn.prepareStatement(insertLoginSQL, Statement.RETURN_GENERATED_KEYS)) {
                pstmt.setString(1, username);
                pstmt.setString(2, password);
                pstmt.setString(3, email);
                pstmt.setString(4, role);
                pstmt.executeUpdate();

                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    userId = rs.getInt(1);
                } else {
                    conn.rollback();
                    return false;
                }
            }

            try (PreparedStatement pstmt = conn.prepareStatement(insertCustSQL)) {
                pstmt.setInt(1, userId);
                pstmt.setString(2, username);
                pstmt.executeUpdate();
            }

            if ("Farmer".equalsIgnoreCase(role)) {
                try (PreparedStatement pstmt = conn.prepareStatement(insertFarmerSQL)) {
                    pstmt.setInt(1, userId);
                    pstmt.setString(2, username + "'s Farm");
                    pstmt.setString(3, username);
                    pstmt.executeUpdate();
                }
            }

            conn.commit();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public User validateUser(String username, String password) {
        String sql = "SELECT ul.user_id, ul.username, ul.email, ul.user_type, " +
                     "c.customer_id, f.farmer_id, f.farm_name " +
                     "FROM user_login ul " +
                     "LEFT JOIN customer c ON ul.user_id = c.user_id " +
                     "LEFT JOIN farmer f ON ul.user_id = f.user_id " +
                     "WHERE ul.username = ? AND ul.password_hash = ?";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);
            pstmt.setString(2, password);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int userId = rs.getInt("user_id");
                    String email = rs.getString("email");
                    String userType = rs.getString("user_type");
                    int customerId = rs.getInt("customer_id");
                    int farmerId = rs.getInt("farmer_id");
                    String farmName = rs.getString("farm_name");

                    if (customerId == 0) {
                        customerId = ensureCustomerProfileExists(conn, userId, username);
                    }

                    if ("Farmer".equalsIgnoreCase(userType)) {
                        return new FarmerUser(userId, username, email, customerId, farmerId, farmName);
                    } else {
                        return new ConsumerUser(userId, username, email, customerId);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    private int ensureCustomerProfileExists(Connection conn, int userId, String username) throws SQLException {
        String insertSQL = "INSERT INTO customer (user_id, first_name, last_name) VALUES (?, ?, 'User')";
        try (PreparedStatement pstmt = conn.prepareStatement(insertSQL, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, userId);
            pstmt.setString(2, username);
            pstmt.executeUpdate();

            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    @Override
    public boolean saveProduce(int farmerId, String name, double price, double quantity) {
        String sql = "INSERT INTO produce (farmer_id, category_id, item_name, price_per_unit, unit_type, stock_quantity, status) " +
                     "VALUES (?, ?, ?, ?, 'kg', ?, 'Available')";

        try (Connection conn = getConnection()) {
            int categoryId = getOrCreateValidCategoryId(conn);

            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, farmerId);
                pstmt.setInt(2, categoryId);
                pstmt.setString(3, name);
                pstmt.setDouble(4, price);
                pstmt.setDouble(5, quantity);

                return pstmt.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Produce> fetchAvailableProduce() {
        List<Produce> list = new ArrayList<>();
        String sql = "SELECT p.produce_id, p.farmer_id, p.item_name, p.price_per_unit, p.stock_quantity, f.farm_name " +
                     "FROM produce p " +
                     "JOIN farmer f ON p.farmer_id = f.farmer_id " +
                     "WHERE p.stock_quantity > 0";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                list.add(new Produce(
                        rs.getInt("produce_id"),
                        rs.getInt("farmer_id"),
                        rs.getString("item_name"),
                        rs.getDouble("price_per_unit"),
                        rs.getDouble("stock_quantity"),
                        rs.getString("farm_name")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public boolean processOrderTransaction(Order order) {
        String insertOrderSQL = "INSERT INTO `order` (customer_id, total_amount, delivery_address) VALUES (?, ?, 'Standard Delivery')";
        String insertItemSQL = "INSERT INTO order_item (order_id, produce_id, quantity, unit_price) VALUES (?, ?, ?, ?)";
        String updateStockSQL = "UPDATE produce SET stock_quantity = stock_quantity - ? WHERE produce_id = ?";
        String insertStatusSQL = "INSERT INTO order_status (order_id, current_status) VALUES (?, 'Paid')";
        String insertPaymentSQL = "INSERT INTO payment (order_id, payment_method, payment_status, amount, card_number_last4, card_holder_name, card_type) " +
                                  "VALUES (?, ?, 'Completed', ?, ?, ?, ?)";

        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false);

            int orderId;
            try (PreparedStatement pstmt = conn.prepareStatement(insertOrderSQL, Statement.RETURN_GENERATED_KEYS)) {
                pstmt.setInt(1, order.getBuyer().getCustomerId());
                pstmt.setDouble(2, order.getTotalAmount());
                pstmt.executeUpdate();

                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    orderId = rs.getInt(1);
                } else {
                    conn.rollback();
                    return false;
                }
            }

            try (PreparedStatement pstmt = conn.prepareStatement(insertItemSQL)) {
                pstmt.setInt(1, orderId);
                pstmt.setInt(2, order.getProduce().getProduceId());
                pstmt.setDouble(3, order.getQuantity());
                pstmt.setDouble(4, order.getProduce().getPricePerUnit());
                pstmt.executeUpdate();
            }

            try (PreparedStatement pstmt = conn.prepareStatement(updateStockSQL)) {
                pstmt.setDouble(1, order.getQuantity());
                pstmt.setInt(2, order.getProduce().getProduceId());
                pstmt.executeUpdate();
            }

            try (PreparedStatement pstmt = conn.prepareStatement(insertStatusSQL)) {
                pstmt.setInt(1, orderId);
                pstmt.executeUpdate();
            }

            PaymentDetails details = order.getPaymentDetails();
            try (PreparedStatement pstmt = conn.prepareStatement(insertPaymentSQL)) {
                pstmt.setInt(1, orderId);
                pstmt.setString(2, details != null ? details.getMethod() : "Cash on Delivery");
                pstmt.setDouble(3, order.getTotalAmount());
                pstmt.setString(4, details != null ? details.getCardNumberLast4() : null);
                pstmt.setString(5, details != null ? details.getCardHolderName() : null);
                pstmt.setString(6, details != null ? details.getCardType() : null);
                pstmt.executeUpdate();
            }

            conn.commit();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<FarmerOrderNotification> fetchOrdersForFarmer(int farmerId) {
        List<FarmerOrderNotification> notifications = new ArrayList<>();
        // Selects produce.stock_quantity to display current remaining stock after order deduction
        String sql = "SELECT o.order_id, c.first_name AS consumer_name, p.item_name, oi.quantity, " +
                     "(oi.quantity * oi.unit_price) AS line_total, p.stock_quantity AS remaining_stock, " +
                     "pay.payment_method, os.current_status " +
                     "FROM order_item oi " +
                     "JOIN `order` o ON oi.order_id = o.order_id " +
                     "JOIN produce p ON oi.produce_id = p.produce_id " +
                     "JOIN customer c ON o.customer_id = c.customer_id " +
                     "LEFT JOIN payment pay ON o.order_id = pay.order_id " +
                     "LEFT JOIN order_status os ON o.order_id = os.order_id " +
                     "WHERE p.farmer_id = ? AND (os.current_status != 'Finished' OR os.current_status IS NULL) " +
                     "ORDER BY o.order_id DESC";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, farmerId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    notifications.add(new FarmerOrderNotification(
                            rs.getInt("order_id"),
                            rs.getString("consumer_name"),
                            rs.getString("item_name"),
                            rs.getDouble("quantity"),
                            rs.getDouble("line_total"),
                            rs.getDouble("remaining_stock"),
                            rs.getString("payment_method"),
                            rs.getString("current_status")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return notifications;
    }

    @Override
    public boolean updateOrderStatus(int orderId, String newStatus) {
        String sql = "UPDATE order_status SET current_status = ? WHERE order_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newStatus);
            pstmt.setInt(2, orderId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean saveCustomerCard(int customerId, String cardHolderName, String cardNumber, String cardType) {
        String sql = "INSERT INTO saved_card (customer_id, card_holder_name, card_number_last4, card_type) VALUES (?, ?, ?, ?)";
        String last4 = (cardNumber != null && cardNumber.length() >= 4)
                ? cardNumber.substring(cardNumber.length() - 4)
                : cardNumber;

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, customerId);
            pstmt.setString(2, cardHolderName);
            pstmt.setString(3, last4);
            pstmt.setString(4, cardType);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<SavedCard> fetchSavedCardsForCustomer(int customerId) {
        List<SavedCard> cards = new ArrayList<>();
        String sql = "SELECT card_id, customer_id, card_holder_name, card_number_last4, card_type FROM saved_card WHERE customer_id = ?";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, customerId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    cards.add(new SavedCard(
                            rs.getInt("card_id"),
                            rs.getInt("customer_id"),
                            rs.getString("card_holder_name"),
                            rs.getString("card_number_last4"),
                            rs.getString("card_type")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cards;
    }

    @Override
    public boolean verifyCardExists(int customerId, String last4Digits) {
        String sql = "SELECT COUNT(*) FROM saved_card WHERE customer_id = ? AND card_number_last4 = ?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, customerId);
            pstmt.setString(2, last4Digits);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private int getOrCreateValidCategoryId(Connection conn) throws SQLException {
        String selectSQL = "SELECT category_id FROM produce_category LIMIT 1";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(selectSQL)) {
            if (rs.next()) {
                return rs.getInt("category_id");
            }
        }

        String insertSQL = "INSERT INTO produce_category (category_name, description) VALUES ('General Produce', 'Fresh farm items')";
        try (PreparedStatement pstmt = conn.prepareStatement(insertSQL, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.executeUpdate();
            ResultSet rsKeys = pstmt.getGeneratedKeys();
            if (rsKeys.next()) {
                return rsKeys.getInt(1);
            }
        }
        return 1;
    }
}