/**
 * 
 */
/**
 * 
 */
module UI {
	requires java.desktop;
	requires java.sql;
}